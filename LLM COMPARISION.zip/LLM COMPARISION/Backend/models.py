from pydantic import BaseModel

class PromptRequest(BaseModel):
    prompt:str
    model:str
    max_tokens:int=150
    temperature:float=0.7