async def call_gemini(prompt: str):
    return f"[gemini Response]\nThis is a simulated response for: {prompt}"