async def call_claude(prompt: str):
    return f"[claude Response]\nThis is a simulated response for: {prompt}"