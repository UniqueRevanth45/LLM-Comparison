Backend:
   
    1)cd Backend

    2)python -m venv venv                                                                            
      venv\Scripts\activate

    3)pip install -r requirements.txt

    4)uvicorn main:app --reload

Frontend:

    1)cd Frontend

    2)python -m http.server 5500