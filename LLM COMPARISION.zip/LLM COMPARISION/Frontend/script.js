async function compare() {
    const prompt = document.getElementById("prompt").value;

    const response = await fetch("http://127.0.0.1:8000/compare", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            prompt: prompt,
            model: "gpt-4",
            max_tokens: 150,
            temperature: 0.7
        })
    });

    const data = await response.json();

    document.getElementById("openai").innerText = data.openai_response;
    document.getElementById("claude").innerText = data.claude_response;
    document.getElementById("gemini").innerText = data.gemini_response;
}
